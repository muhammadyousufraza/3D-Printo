/* global confirm, redux, redux_change */

!function($) {
	$(document).ready(function() {
		$("#haru_header-select").select2();
	});
}(jQuery);