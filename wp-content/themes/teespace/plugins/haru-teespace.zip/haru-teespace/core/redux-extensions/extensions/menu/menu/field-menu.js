/* global confirm, redux, redux_change */
!function($) {
	$(document).ready(function() {
		$("#menu_add_register_link-select").select2({
	  		allowClear: true
		});
	});
}(jQuery);